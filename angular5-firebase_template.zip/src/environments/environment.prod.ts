export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyB26F_hNe89LkcfKX2CE0mrmYQDXv0U3FQ',
    authDomain: 'niceglobals-ebf54.firebaseapp.com',
    databaseURL: 'https://niceglobals-ebf54.firebaseio.com',
    projectId: 'niceglobals-ebf54',
    storageBucket: 'niceglobals-ebf54.appspot.com',
    messagingSenderId: '14582184582'
  }
};
