import { Component, OnInit } from '@angular/core';
import { NotificationService } from './services/notification.service';
import { Note } from './models/notification.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'app';
  notification = new Note();
  constructor(public _notes: NotificationService) {}

  ngOnInit() {
    this.notification.message = null;
    this._notes.noteChanged.subscribe(
      (note: any) => {
        this.notification = note;
        // console.log(this.notification);
      }
    );
  }
}
