import { Routes } from '@angular/router';
import { HomeComponent } from './comp/home/home.component';
import { AboutComponent } from './comp/about/about.component';
import { WhoWeAreComponent } from './comp/about/who-we-are/who-we-are.component';
import { OurApproachComponent } from './comp/about/our-approach/our-approach.component';
import { TrainingsComponent } from './comp/trainings/trainings.component';


export const appRoutes: Routes = [
  {path: '', component: HomeComponent},
  {path: 'our_approach', component: OurApproachComponent},
  {path: 'who_we_are', component: WhoWeAreComponent},
  {path: 'trainings', component: TrainingsComponent}
];
