import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import * as firebase from 'firebase/app';
import { AuthService } from '../../../services/auth.service';
import { FirebaseApp } from 'angularfire2/app';
import { AngularFireAuth } from 'angularfire2/auth';
import { CurUser } from '../../../models/cuser.model';
import { FireService } from '../../../services/fire.service';
import { UserService } from '../../../services/user.service';
import { NotificationService } from '../../../services/notification.service';
import { AuthReq } from '../../../models/auth.request';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
// loggedIn = false;
authMode = false;
authMethod = 0;
showPass = false;
curUser = new CurUser();
newUser = new CurUser();
user: Observable<firebase.User>;

  constructor(public _auth: AuthService, private _router: Router,
    private _afAuth: AngularFireAuth, private _note: NotificationService,
    private _fire: FireService, private _us: UserService) { }

  ngOnInit() {
    this._auth.authReqChanged.subscribe(
      (authReq: AuthReq) => {
        this.authMethod = authReq.authMethod;
        this.authMode = authReq.authMode;
      }
    );
    this.curUser = null;
    this.user = this._auth.authUser();
    this._us.curUserUpdated.subscribe(
      (user: any) => {
        this.curUser = user;
        console.log(this.curUser);
      }
    );
  }

  login(f: any) {
    console.log(f);
    // this.loggedIn = true;
    this._auth.login(f).then(
      success => {
        this.closeAuth();
        if (this.user) {
          const uid = this._afAuth.auth.currentUser.uid;
          console.log(uid);
          this._note.setNote('Logged in successfully', 'success');
        }
      }
    ).catch(
      (err: any) => {
        console.log(err);
        if (err.code === 'auth/user-not-found') {
          this._note.setNote('User does not exist, Please check your email or Register', 'failed');
        }
        if (err.code === 'auth/wrong-password') {
          this._note.setNote('Invalid email or password', 'failed');
        }
      }
    );
  }

  register(f: CurUser) {
    console.log(f);
    this.newUser = f;
    this.newUser.registrationTime = new Date().getTime();
    this._auth.registerUser(f, this.newUser).then( e => {
      this.closeAuth();
      this._note.setNote('Registered successfully', 'success');
      this.newUser = new CurUser();
    }).catch(
      err => {
        this._note.setNote(err.message, 'failed');
      }
    );
  }

  logout() {
    this.curUser = null;
    this._auth.logout().then(onResolve => {
      this._note.setNote('Logged out successfully', 'warning');
      this._router.navigate(['/']);
    });
  }

  forAuth(id: number) {
    this.authMode = true;
    if (id < 3) {
      this.authMethod = id;
    }
    this.showPass = false;
  }
  closeAuth() {
    this.authMode = false;
    this.authMethod = 0;
  }
  showHidePass() {
    this.showPass = !this.showPass;
  }

  setNote() {
    this._note.setNote('hi', 'success');
  }
}
