import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { environment} from '../environments/environment';
import { FormsModule } from '@angular/forms';

import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

import { RouterModule } from '@angular/router';
import { appRoutes } from './routes';

import { AngularFireModule } from 'angularfire2';
import { AngularFireDatabaseModule } from 'angularfire2/database';
import { AngularFireAuthModule } from 'angularfire2/auth';

import { AppComponent } from './app.component';
import { HeaderComponent } from './comp/basic/header/header.component';
import { FooterComponent } from './comp/basic/footer/footer.component';
import { HomeComponent } from './comp/home/home.component';
import { Slider1Component } from './comp/sliders/slider1/slider1.component';
import { LoginComponent } from './comp/basic/login/login.component';

import { AuthService } from './services/auth.service';
import { AuthenticationGuardService } from './services/authentication-guard.service';
import { FireService } from './services/fire.service';
import { UserService } from './services/user.service';
import { NotificationService } from './services/notification.service';
import { AboutComponent } from './comp/about/about.component';
import { WhoWeAreComponent } from './comp/about/who-we-are/who-we-are.component';
import { OurApproachComponent } from './comp/about/our-approach/our-approach.component';
import { TrainingsComponent } from './comp/trainings/trainings.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    Slider1Component,
    LoginComponent,
    AboutComponent,
    WhoWeAreComponent,
    OurApproachComponent,
    TrainingsComponent
  ],
  imports: [
    BrowserModule, FormsModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(appRoutes),
    AngularFireModule.initializeApp(environment.firebase),
    AngularFireDatabaseModule,
    AngularFireAuthModule,
    NgbModule.forRoot()
  ],
  providers: [AuthService, AuthenticationGuardService, FireService, UserService, NotificationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
