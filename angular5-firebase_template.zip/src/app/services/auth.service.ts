import { Injectable } from '@angular/core';
import { AngularFireAuth } from 'angularfire2/auth';
import * as firebase from 'firebase/app';
import { Observable } from 'rxjs/Observable';
import { User } from '../models/user.model';
import { AngularFireDatabase } from 'angularfire2/database';
import { CurUser } from '../models/cuser.model';
import { AuthReq } from '../models/auth.request';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class AuthService {
  private user: Observable<firebase.User>;
  private basePath = '/db/users';
  authReq = new AuthReq();
  authReqChanged = new Subject<AuthReq>();

  constructor(private afAuth: AngularFireAuth, private db: AngularFireDatabase ) {
    this.user = afAuth.authState;
  }

  login(user: User) {
    return this.afAuth.auth.signInWithEmailAndPassword(user.email, user.password);
  }

  logout() {
    return this.afAuth.auth.signOut();
  }

  authUser() {
    return this.user;
  }
  registerUser(user: User, cUser: CurUser) {
    return this.afAuth.auth.createUserWithEmailAndPassword(user.email, user.password).then(
      success => {
        console.log(success);
        cUser.uid = success.uid;
        const uid = success.uid;
        console.log(uid);
        // this.db.
        firebase.database().ref('/db/users/' + uid).set(cUser);
        // this.db.list(`${this.basePath}/${uid}`).set(cUser);
      }
    );
  }
  setDisplayName(name: string) {

  }

  reqAuth(id?: number) {
    if (id != null && id !== undefined) {
      this.authReq.authMethod = id;
    } else {
      this.authReq.authMethod = 0;
    }
    this.authReq.authMode = true;
    this.authReqChanged.next(this.authReq);
  }
}
