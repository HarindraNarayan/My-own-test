import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFireDatabase } from 'angularfire2/database';
import { FirebaseApp } from 'angularfire2';
import * as firebase from 'firebase';
import { CurUser } from '../models/cuser.model';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class UserService {
  private uid: string;
  curUserUpdated = new Subject<CurUser[]>();
  curUser = new CurUser();
  fdb = firebase.database();
  constructor(private afAuth: AngularFireAuth, private db: AngularFireDatabase) {
    this.afAuth.authState.subscribe(auth => {
      if (auth !== undefined && auth !== null) {
        this.uid = auth.uid;
        this.fdb.ref('db/users/' + this.uid).once('value').then(
          snap => {
            const data = snap.val();
            this.setCurUser(data);
          }
        );
      }
    });
   }

   setCurUser(data: any) {
     this.curUser = data;
     this.curUserUpdated.next(data);
   }
}
