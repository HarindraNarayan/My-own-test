export class User {
  uid?: string;
  email?: string;
  password?: string;
  userName?: string;
}
