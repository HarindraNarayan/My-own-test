export class CurUser {
  uid?: string;
  email?: string;
  userName?: string;
  userType?: string;
  registrationTime?: number;
  mobileNo?: number;
}
