export class AuthReq {
  authMode?: boolean;
  authMethod?: number;
}
