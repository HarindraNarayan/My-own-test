export class Note {
  noteType?: string;
  message?: string;
}
